import json

import requests
from django import template

register = template.Library()  # register的名字是固定的,不可改变


def getContent(uid):
    se = requests.session()
    title1, da1, category1, auName1, content = [], [], [], [], []
    Post_url = "http://v.juhe.cn/toutiao/content"
    Post_data = {
        "type": "top",
        "uniquekey": uid,
        'key': '8a45f29878e064ebfa92d6dc7fd1fc86'
    }
    Text = se.post(Post_url, data=Post_data).text
    try:
        result = json.loads(Text)
        content.append(result['result']['content'])
    except Exception as e:
        pass
    return content[0]


@register.filter
def my_filter(uid):
    content = getContent(uid)
    content = content.replace("<p >", "")
    content = content.replace("</p>", "")
    content = content.replace("\n", "")
    content = content.replace("  ", "")
    import re
    content = re.sub(r"<img (.*)>", "", content)
    return content[4:65] + "...."

register.filter('my_filter', my_filter)
