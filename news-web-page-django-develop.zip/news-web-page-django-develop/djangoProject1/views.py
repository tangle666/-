"""def index(request):
    return HttpResponse("hello")


def get(request):
    # 使用 render 来替代之前使用的 HttpResponse,render 还使用了一个字典 context 作为参数。
    # context 字典中元素的键值 hello 对应了模板中的变量 {{ hello }}
    return render(request, 'index.html', {"hello": "hello world"})


def getList(request):
    # html中可以用 . 索引下标取出对应的元素。
    views_list = ["菜鸟教程1","菜鸟教程2","菜鸟教程3"]
    return render(request, "index.html", {"views_list": views_list})


def getDict(request):
    dic = {"name": "nmsl"}
    return render(request, "index.html", {"diction": dic})


def time(request):
    import datetime
    now = datetime.datetime.now()
    return render(request, "index.html", {"time": now})


def turn(request):
    views_str = "<a href='https://www.runoob.com/'>点击跳转</a>"
    return render(request, "index.html", {"views_str": views_str})


def ifCode(request):
    views_num = 88
    return render(request, "index.html", {"num": views_num})


def forCode(request):
    views_list = ["菜鸟教程", "菜鸟教程1", "菜鸟教程2", "菜鸟教程3", ]
    return render(request, "index.html", {"views_list": views_list})
"""

from django.http import HttpResponse
from django.shortcuts import render
import requests
import time
import re
import json


class G:
    uid = ""


def getNews():
    se = requests.session()
    title, da, newsUrl, imgUrl, uid, content, auName = [], [], [], [], [], [], []
    Post_url = "http://v.juhe.cn/toutiao/index"
    Post_data = {
        "type": "top",
        'key': '8a45f29878e064ebfa92d6dc7fd1fc86'
    }
    Text = se.post(Post_url, data=Post_data).text
    try:
        result = json.loads(Text)
        error_code = result['error_code']
        if (error_code == 0):
            data = result['result']['data']
            for i in data:
                title.append(i['title'])
                da.append(i['date'])
                newsUrl.append(i['url'])
                imgUrl.append(i['thumbnail_pic_s'])
                uid.append(i['uniquekey'])
                auName.append(i['author_name'])
    except Exception as e:
        pass
    return title, da, newsUrl, imgUrl, uid, content, auName


def showNews(request):
    title, da, newsUrl, imgUrl, uid, content, auName = getNews()
    return render(request, "index.html", {"title": title, "da": da, "imgUrl": imgUrl, "uid": uid, "auName": auName})


def getContent(uid):
    se = requests.session()
    title1, da1, category1, auName1, content = [], [], [], [], []
    Post_url = "http://v.juhe.cn/toutiao/content"
    Post_data = {
        "type": "top",
        "uniquekey": uid,
        'key': '8a45f29878e064ebfa92d6dc7fd1fc86'
    }
    Text = se.post(Post_url, data=Post_data).text
    try:
        result = json.loads(Text)
        detail = result['result']['detail']
        title1.append(detail['title'])
        da1.append(detail['date'])
        category1.append(detail['category'])
        auName1.append(detail['author_name'])
        content.append(result['result']['content'])
    except Exception as e:
        pass
    return title1, da1, category1, auName1, content


def showContent(request):
    uid = request.GET.get("uid")
    G.uid = uid
    title1, da1, category1, auName1, content = getContent(G.uid)
    return render(request, "content.html", {"title1": title1, "da1": da1, "category1": category1,
                                            "auName1": auName1, "content": content})
