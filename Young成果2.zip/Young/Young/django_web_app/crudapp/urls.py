from django.urls import path
from . import views
urlpatterns = [
    path('', views.首页, name='首页'),
    path('users/', views.用户列表, name='用户列表'),
    path('users/new/', views.用户新增, name='用户新增'),
    path('users/<int:pk>/', views.用户详情, name='用户详情'),
    path('users/<int:pk>/edit/', views.用户编辑, name='用户编辑'),
    path('users/<int:pk>/delete/', views.用户删除, name='用户删除'),
    path('items/', views.物品列表, name='物品列表'),
    path('items/new/', views.物品新增, name='物品新增'),
    path('items/<int:pk>/', views.物品详情, name='物品详情'),
    path('items/<int:pk>/edit/', views.物品编辑, name='物品编辑'),
    path('items/<int:pk>/delete/', views.物品删除, name='物品删除'),
]
