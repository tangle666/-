import os
import json
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, 'storage')
USERS = os.path.join(DATA_DIR, 'users.json')
ITEMS = os.path.join(DATA_DIR, 'items.json')

def 确保存储():
    if not os.path.exists(DATA_DIR):
        os.makedirs(DATA_DIR)
    if not os.path.exists(USERS):
        with open(USERS, 'w', encoding='utf-8') as f:
            json.dump([], f, ensure_ascii=False)
    if not os.path.exists(ITEMS):
        with open(ITEMS, 'w', encoding='utf-8') as f:
            json.dump([], f, ensure_ascii=False)

def 读取(path):
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)

def 写入(path, data):
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def 首页(request):
    return render(request, 'index.html')

def 用户列表(request):
    确保存储()
    数据 = 读取(USERS)
    q = request.GET.get('q', '').strip()
    if q:
        数据 = [x for x in 数据 if q in x.get('姓名','')]
    return render(request, 'users_list.html', {'数据': 数据, '关键词': q})

def 用户详情(request, pk):
    确保存储()
    数据 = 读取(USERS)
    项 = next((x for x in 数据 if x.get('id')==pk), None)
    if not 项:
        return HttpResponse('未找到')
    return render(request, 'user_detail.html', {'项': 项})

def 下一个ID(数据):
    if not 数据:
        return 1
    return max(x.get('id',0) for x in 数据)+1

def 用户新增(request):
    确保存储()
    if request.method=='POST':
        数据 = 读取(USERS)
        项 = {
            'id': 下一个ID(数据),
            '姓名': request.POST.get('姓名','').strip(),
            '邮箱': request.POST.get('邮箱','').strip(),
            '角色': request.POST.get('角色','').strip(),
        }
        数据.append(项)
        写入(USERS, 数据)
        return HttpResponseRedirect(reverse('用户列表'))
    return render(request, 'user_form.html', {'标题':'新增用户','提交':'保存'})

def 用户编辑(request, pk):
    确保存储()
    数据 = 读取(USERS)
    项 = next((x for x in 数据 if x.get('id')==pk), None)
    if not 项:
        return HttpResponse('未找到')
    if request.method=='POST':
        项['姓名'] = request.POST.get('姓名','').strip()
        项['邮箱'] = request.POST.get('邮箱','').strip()
        项['角色'] = request.POST.get('角色','').strip()
        写入(USERS, 数据)
        return HttpResponseRedirect(reverse('用户列表'))
    return render(request, 'user_form.html', {'标题':'编辑用户','提交':'更新','项':项})

def 用户删除(request, pk):
    确保存储()
    数据 = 读取(USERS)
    项 = next((x for x in 数据 if x.get('id')==pk), None)
    if not 项:
        return HttpResponse('未找到')
    if request.method=='POST':
        数据 = [x for x in 数据 if x.get('id')!=pk]
        写入(USERS, 数据)
        return HttpResponseRedirect(reverse('用户列表'))
    return render(request, 'users_confirm_delete.html', {'项':项})

def 物品列表(request):
    确保存储()
    数据 = 读取(ITEMS)
    q = request.GET.get('q', '').strip()
    if q:
        数据 = [x for x in 数据 if q in x.get('名称','')]
    return render(request, 'items_list.html', {'数据': 数据, '关键词': q})

def 物品详情(request, pk):
    确保存储()
    数据 = 读取(ITEMS)
    项 = next((x for x in 数据 if x.get('id')==pk), None)
    if not 项:
        return HttpResponse('未找到')
    return render(request, 'item_detail.html', {'项': 项})

def 物品新增(request):
    确保存储()
    if request.method=='POST':
        数据 = 读取(ITEMS)
        项 = {
            'id': 下一个ID(数据),
            '名称': request.POST.get('名称','').strip(),
            '数量': int(request.POST.get('数量','0') or '0'),
            '描述': request.POST.get('描述','').strip(),
        }
        数据.append(项)
        写入(ITEMS, 数据)
        return HttpResponseRedirect(reverse('物品列表'))
    return render(request, 'item_form.html', {'标题':'新增物品','提交':'保存'})

def 物品编辑(request, pk):
    确保存储()
    数据 = 读取(ITEMS)
    项 = next((x for x in 数据 if x.get('id')==pk), None)
    if not 项:
        return HttpResponse('未找到')
    if request.method=='POST':
        项['名称'] = request.POST.get('名称','').strip()
        项['数量'] = int(request.POST.get('数量','0') or '0')
        项['描述'] = request.POST.get('描述','').strip()
        写入(ITEMS, 数据)
        return HttpResponseRedirect(reverse('物品列表'))
    return render(request, 'item_form.html', {'标题':'编辑物品','提交':'更新','项':项})

def 物品删除(request, pk):
    确保存储()
    数据 = 读取(ITEMS)
    项 = next((x for x in 数据 if x.get('id')==pk), None)
    if not 项:
        return HttpResponse('未找到')
    if request.method=='POST':
        数据 = [x for x in 数据 if x.get('id')!=pk]
        写入(ITEMS, 数据)
        return HttpResponseRedirect(reverse('物品列表'))
    return render(request, 'items_confirm_delete.html', {'项':项})
