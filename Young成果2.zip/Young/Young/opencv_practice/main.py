import os
import cv2
import numpy as np
from matplotlib import pyplot as plt

def 确保目录(p):
    if not os.path.exists(p):
        os.makedirs(p)

def 读取图像(路径):
    return cv2.imdecode(np.fromfile(路径, dtype=np.uint8), cv2.IMREAD_COLOR)

def 保存图像(路径, 图像):
    ext = os.path.splitext(路径)[1]
    if ext.lower() in ['.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.webp']:
        cv2.imencode(ext, 图像)[1].tofile(路径)
    else:
        cv2.imencode('.png', 图像)[1].tofile(路径)

def 基本操作(输入路径, 输出目录):
    img = 读取图像(输入路径)
    if img is None:
        print('读取失败')
        return
    保存图像(os.path.join(输出目录, '原图.png'), img)
    h, w = img.shape[:2]
    缩放 = cv2.resize(img, (w//2, h//2))
    保存图像(os.path.join(输出目录, '缩放_0.5x.png'), 缩放)
    M = cv2.getRotationMatrix2D((w/2, h/2), 30, 1.0)
    旋转 = cv2.warpAffine(img, M, (w, h))
    保存图像(os.path.join(输出目录, '旋转_30度.png'), 旋转)
    print('已完成：读取 显示(保存代替) 保存 缩放 旋转')

def 平滑处理(输入路径, 输出目录):
    img = 读取图像(输入路径)
    if img is None:
        print('读取失败')
        return
    高斯 = cv2.GaussianBlur(img, (5,5), 1.2)
    中值 = cv2.medianBlur(img, 5)
    双边 = cv2.bilateralFilter(img, 9, 75, 75)
    保存图像(os.path.join(输出目录, '原图.png'), img)
    保存图像(os.path.join(输出目录, '高斯.png'), 高斯)
    保存图像(os.path.join(输出目录, '中值.png'), 中值)
    保存图像(os.path.join(输出目录, '双边.png'), 双边)
    对比 = np.hstack((cv2.resize(img, (0,0), fx=0.5, fy=0.5), cv2.resize(高斯, (0,0), fx=0.5, fy=0.5), cv2.resize(中值, (0,0), fx=0.5, fy=0.5), cv2.resize(双边, (0,0), fx=0.5, fy=0.5)))
    保存图像(os.path.join(输出目录, '对比.png'), 对比)
    print('已完成：高斯 中值 双边 滤波与对比')

def 边缘检测(输入路径, 输出目录):
    img = 读取图像(输入路径)
    if img is None:
        print('读取失败')
        return
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    canny = cv2.Canny(gray, 100, 200)
    sobelx = cv2.Sobel(gray, cv2.CV_16S, 1, 0)
    sobely = cv2.Sobel(gray, cv2.CV_16S, 0, 1)
    sobel = cv2.convertScaleAbs(cv2.addWeighted(cv2.convertScaleAbs(sobelx), 0.5, cv2.convertScaleAbs(sobely), 0.5, 0))
    保存图像(os.path.join(输出目录, 'Canny.png'), canny)
    保存图像(os.path.join(输出目录, 'Sobel.png'), sobel)
    print('已完成：Canny Sobel')

def 轮廓分析(输入路径, 输出目录):
    img = 读取图像(输入路径)
    if img is None:
        print('读取失败')
        return
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (5,5), 1.0)
    _, th = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY+cv2.THRESH_OTSU)
    contours, hierarchy = cv2.findContours(th, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    绘制 = img.copy()
    特征文本 = []
    for i, c in enumerate(contours):
        area = cv2.contourArea(c)
        peri = cv2.arcLength(c, True)
        x, y, w, h = cv2.boundingRect(c)
        cv2.drawContours(绘制, [c], -1, (0,255,0), 2)
        cv2.rectangle(绘制, (x,y), (x+w,y+h), (0,0,255), 2)
        特征文本.append(f'索引={i}, 面积={area:.2f}, 周长={peri:.2f}, 边界框=({x},{y},{w},{h})')
    保存图像(os.path.join(输出目录, '阈值.png'), th)
    保存图像(os.path.join(输出目录, '轮廓.png'), 绘制)
    with open(os.path.join(输出目录, '轮廓特征.txt'), 'w', encoding='utf-8') as f:
        f.write('\n'.join(特征文本))
    print('已完成：轮廓查找 绘制 面积 周长 边界框')

def 模板匹配(输入路径, 模板路径, 输出目录):
    img = 读取图像(输入路径)
    tpl = 读取图像(模板路径) if 模板路径 else None
    if img is None or tpl is None:
        print('读取失败或缺少模板')
        return
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    tplg = cv2.cvtColor(tpl, cv2.COLOR_BGR2GRAY)
    res = cv2.matchTemplate(gray, tplg, cv2.TM_CCOEFF_NORMED)
    min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(res)
    h, w = tplg.shape[:2]
    tl = max_loc
    br = (tl[0]+w, tl[1]+h)
    绘制 = img.copy()
    cv2.rectangle(绘制, tl, br, (0,0,255), 2)
    保存图像(os.path.join(输出目录, '模板.png'), tpl)
    保存图像(os.path.join(输出目录, '匹配结果.png'), 绘制)
    with open(os.path.join(输出目录, '匹配评分.txt'), 'w', encoding='utf-8') as f:
        f.write(f'最大相关={max_val:.4f}, 左上角={tl}, 右下角={br}')
    print('已完成：模板匹配')

def 人脸检测(输入路径, 输出目录):
    img = 读取图像(输入路径)
    if img is None:
        print('读取失败')
        return
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    xml = os.path.join(cv2.data.haarcascades, 'haarcascade_frontalface_default.xml')
    clf = cv2.CascadeClassifier(xml)
    faces = clf.detectMultiScale(gray, 1.2, 5)
    绘制 = img.copy()
    for (x,y,w,h) in faces:
        cv2.rectangle(绘制, (x,y), (x+w,y+h), (0,255,0), 2)
    保存图像(os.path.join(输出目录, '人脸.png'), 绘制)
    with open(os.path.join(输出目录, '人脸数量.txt'), 'w', encoding='utf-8') as f:
        f.write(str(len(faces)))
    print('已完成：人脸检测')

def 图像增强与形态学(输入路径, 输出目录):
    img = 读取图像(输入路径)
    if img is None:
        print('读取失败')
        return
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    全局 = cv2.equalizeHist(gray)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
    自适应 = clahe.apply(gray)
    lap = cv2.Laplacian(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY), cv2.CV_16S)
    lap = cv2.convertScaleAbs(lap)
    锐化 = cv2.addWeighted(gray, 1.0, lap, -0.3, 0)
    _, th = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY+cv2.THRESH_OTSU)
    k = cv2.getStructuringElement(cv2.MORPH_RECT, (3,3))
    腐蚀 = cv2.erode(th, k, iterations=1)
    膨胀 = cv2.dilate(th, k, iterations=1)
    开 = cv2.morphologyEx(th, cv2.MORPH_OPEN, k)
    闭 = cv2.morphologyEx(th, cv2.MORPH_CLOSE, k)
    保存图像(os.path.join(输出目录, '直方图均衡_全局.png'), 全局)
    保存图像(os.path.join(输出目录, '直方图均衡_CLAHE.png'), 自适应)
    保存图像(os.path.join(输出目录, '锐化.png'), 锐化)
    保存图像(os.path.join(输出目录, '二值.png'), th)
    保存图像(os.path.join(输出目录, '腐蚀.png'), 腐蚀)
    保存图像(os.path.join(输出目录, '膨胀.png'), 膨胀)
    保存图像(os.path.join(输出目录, '开运算.png'), 开)
    保存图像(os.path.join(输出目录, '闭运算.png'), 闭)
    print('已完成：直方图均衡 CLAHE 锐化 腐蚀 膨胀 开 闭')

def 颜色空间与分割(输入路径, 输出目录):
    img = 读取图像(输入路径)
    if img is None:
        print('读取失败')
        return
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    lower1 = np.array([0, 120, 70])
    upper1 = np.array([10, 255, 255])
    lower2 = np.array([170, 120, 70])
    upper2 = np.array([180, 255, 255])
    mask1 = cv2.inRange(hsv, lower1, upper1)
    mask2 = cv2.inRange(hsv, lower2, upper2)
    mask = cv2.bitwise_or(mask1, mask2)
    res = cv2.bitwise_and(img, img, mask=mask)
    保存图像(os.path.join(输出目录, '红色掩膜.png'), mask)
    保存图像(os.path.join(输出目录, '红色区域.png'), res)
    print('已完成：HSV红色提取')

def 金字塔(输入路径, 输出目录):
    img = 读取图像(输入路径)
    if img is None:
        print('读取失败')
        return
    g1 = cv2.pyrDown(img)
    g2 = cv2.pyrDown(g1)
    l1 = cv2.subtract(img, cv2.pyrUp(g1, dstsize=(img.shape[1], img.shape[0])))
    g1u = cv2.pyrUp(g2, dstsize=(g1.shape[1], g1.shape[0]))
    l2 = cv2.subtract(g1, g1u)
    保存图像(os.path.join(输出目录, '高斯_1.png'), g1)
    保存图像(os.path.join(输出目录, '高斯_2.png'), g2)
    保存图像(os.path.join(输出目录, '拉普拉斯_1.png'), l1)
    保存图像(os.path.join(输出目录, '拉普拉斯_2.png'), l2)
    print('已完成：高斯金字塔 拉普拉斯金字塔')

def 菜单():
    print('选择任务')
    print('1 基本操作')
    print('2 平滑处理')
    print('3 边缘检测')
    print('4 轮廓分析')
    print('5 模板匹配')
    print('6 人脸检测')
    print('7 图像增强与形态学')
    print('8 颜色空间与分割')
    print('9 图像金字塔')

if __name__ == '__main__':
    输出目录 = os.path.join(os.path.dirname(__file__), 'outputs')
    确保目录(输出目录)
    菜单()
    路径 = input('输入图像路径: ').strip().strip('"')
    选项 = input('输入任务编号: ').strip()
    if 选项 == '1':
        基本操作(路径, 输出目录)
    elif 选项 == '2':
        平滑处理(路径, 输出目录)
    elif 选项 == '3':
        边缘检测(路径, 输出目录)
    elif 选项 == '4':
        轮廓分析(路径, 输出目录)
    elif 选项 == '5':
        模板 = input('输入模板路径: ').strip().strip('"')
        模板匹配(路径, 模板, 输出目录)
    elif 选项 == '6':
        人脸检测(路径, 输出目录)
    elif 选项 == '7':
        图像增强与形态学(路径, 输出目录)
    elif 选项 == '8':
        颜色空间与分割(路径, 输出目录)
    elif 选项 == '9':
        金字塔(路径, 输出目录)
    else:
        print('无效选择')
