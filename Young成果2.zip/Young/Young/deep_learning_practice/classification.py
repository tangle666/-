import os
import json
import time
import numpy as np
import tensorflow as tf
import tensorflow_datasets as tfds
import matplotlib.pyplot as plt

def 确保目录(p):
    if not os.path.exists(p):
        os.makedirs(p)

def 加载数据():
    ds, info = tfds.load('cifar10', split=['train', 'test'], as_supervised=True, with_info=True)
    训练集, 测试集 = ds
    num_classes = info.features['label'].num_classes
    return 训练集, 测试集, num_classes

def 预处理(x, y):
    x = tf.cast(x, tf.float32) / 255.0
    return x, y

def 构建MLP(num_classes):
    m = tf.keras.Sequential([
        tf.keras.layers.Flatten(input_shape=(32,32,3)),
        tf.keras.layers.Dense(256, activation='relu'),
        tf.keras.layers.Dense(128, activation='relu'),
        tf.keras.layers.Dense(num_classes, activation='softmax')
    ])
    m.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
    return m

def 构建CNN(num_classes):
    i = tf.keras.Input(shape=(32,32,3))
    x = tf.keras.layers.Conv2D(32,3,activation='relu',padding='same')(i)
    x = tf.keras.layers.MaxPooling2D()(x)
    x = tf.keras.layers.Conv2D(64,3,activation='relu',padding='same')(x)
    x = tf.keras.layers.MaxPooling2D()(x)
    x = tf.keras.layers.Conv2D(128,3,activation='relu',padding='same')(x)
    x = tf.keras.layers.GlobalAveragePooling2D()(x)
    x = tf.keras.layers.Dense(128,activation='relu')(x)
    o = tf.keras.layers.Dense(num_classes,activation='softmax')(x)
    m = tf.keras.Model(i,o)
    m.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
    return m

def 构建VGG简化(num_classes):
    i = tf.keras.Input(shape=(32,32,3))
    def 块(x, f, n):
        for _ in range(n):
            x = tf.keras.layers.Conv2D(f,3,activation='relu',padding='same')(x)
        x = tf.keras.layers.MaxPooling2D()(x)
        return x
    x = 块(i, 64, 2)
    x = 块(x, 128, 2)
    x = 块(x, 256, 2)
    x = tf.keras.layers.Flatten()(x)
    x = tf.keras.layers.Dense(256, activation='relu')(x)
    x = tf.keras.layers.Dense(128, activation='relu')(x)
    o = tf.keras.layers.Dense(num_classes, activation='softmax')(x)
    m = tf.keras.Model(i,o)
    m.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
    return m

def 训练与评估(模型名, 构建器, 训练集, 测试集, 保存目录):
    print(f'开始训练 {模型名}')
    批大小 = 128
    轮数 = 5
    train_ds = 训练集.map(预处理, num_parallel_calls=tf.data.AUTOTUNE).shuffle(10000).batch(批大小).prefetch(tf.data.AUTOTUNE)
    test_ds = 测试集.map(预处理, num_parallel_calls=tf.data.AUTOTUNE).batch(批大小).prefetch(tf.data.AUTOTUNE)
    m = 构建器()
    t0 = time.time()
    h = m.fit(train_ds, epochs=轮数, validation_data=test_ds)
    tt = time.time()-t0
    loss, acc = m.evaluate(test_ds, verbose=0)
    历史 = {'loss': [float(x) for x in h.history['loss']], 'val_loss': [float(x) for x in h.history['val_loss']], 'accuracy': [float(x) for x in h.history['accuracy']], 'val_accuracy': [float(x) for x in h.history['val_accuracy']], 'time_sec': tt}
    with open(os.path.join(保存目录, f'{模型名}_指标.json'), 'w', encoding='utf-8') as f:
        json.dump(历史, f, ensure_ascii=False, indent=2)
    plt.figure()
    plt.plot(历史['loss'], label='训练损失')
    plt.plot(历史['val_loss'], label='验证损失')
    plt.legend()
    plt.savefig(os.path.join(保存目录, f'{模型名}_损失.png'))
    plt.close()
    plt.figure()
    plt.plot(历史['accuracy'], label='训练准确率')
    plt.plot(历史['val_accuracy'], label='验证准确率')
    plt.legend()
    plt.savefig(os.path.join(保存目录, f'{模型名}_准确率.png'))
    plt.close()
    print(f'完成 {模型名} 验证准确率={acc:.4f} 用时={tt:.1f}秒')

if __name__ == '__main__':
    输出 = os.path.join(os.path.dirname(__file__), 'outputs')
    确保目录(输出)
    训练集, 测试集, 类别 = 加载数据()
    训练与评估('MLP', lambda: 构建MLP(类别), 训练集, 测试集, 输出)
    训练与评估('CNN', lambda: 构建CNN(类别), 训练集, 测试集, 输出)
    训练与评估('VGG简化', lambda: 构建VGG简化(类别), 训练集, 测试集, 输出)
