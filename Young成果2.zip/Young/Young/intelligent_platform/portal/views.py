import os
import json
import uuid
import time
import cv2
import numpy as np
from django.shortcuts import render
from django.http import HttpResponseRedirect
from django.urls import reverse
from django.conf import settings
import tensorflow as tf
from PIL import Image
from tensorflow.keras.applications.mobilenet_v2 import MobileNetV2, preprocess_input, decode_predictions

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STORAGE_DIR = os.path.join(BASE_DIR, 'storage')
HISTORY_PATH = os.path.join(STORAGE_DIR, 'history.json')
UPLOAD_DIR = os.path.join(settings.MEDIA_ROOT, 'uploads')
RESULT_DIR = os.path.join(settings.MEDIA_ROOT, 'results')

def 确保目录(p):
    if not os.path.exists(p):
        os.makedirs(p)

def 初始化():
    确保目录(settings.MEDIA_ROOT)
    确保目录(UPLOAD_DIR)
    确保目录(RESULT_DIR)
    确保目录(STORAGE_DIR)
    if not os.path.exists(HISTORY_PATH):
        with open(HISTORY_PATH, 'w', encoding='utf-8') as f:
            json.dump([], f, ensure_ascii=False)

def 保存上传(f):
    名 = f.name
    前缀 = str(int(time.time())) + '_' + uuid.uuid4().hex[:8]
    目标 = os.path.join(UPLOAD_DIR, 前缀 + '_' + 名)
    with open(目标, 'wb') as dst:
        for chunk in f.chunks():
            dst.write(chunk)
    return 目标

def 读图(路径):
    return cv2.imdecode(np.fromfile(路径, dtype=np.uint8), cv2.IMREAD_COLOR)

def 存图(路径, 图像):
    ext = os.path.splitext(路径)[1]
    if ext.lower() not in ['.png', '.jpg', '.jpeg', '.bmp', '.webp']:
        路径 = 路径 + '.png'
    ok, buf = cv2.imencode(os.path.splitext(路径)[1] or '.png', 图像)
    if ok:
        buf.tofile(路径)
    return 路径

def 记录历史(项):
    with open(HISTORY_PATH, 'r', encoding='utf-8') as f:
        数据 = json.load(f)
    数据.insert(0,项)
    with open(HISTORY_PATH, 'w', encoding='utf-8') as f:
        json.dump(数据, f, ensure_ascii=False, indent=2)

def 首页(request):
    初始化()
    return render(request, 'index.html')

def 处理(request):
    初始化()
    if request.method != 'POST':
        return HttpResponseRedirect(reverse('首页'))
    图片 = request.FILES.get('image')
    方法 = request.POST.get('method','')
    模板 = request.FILES.get('template')
    if not 图片 or not 方法:
        return HttpResponseRedirect(reverse('首页'))
    原图路径 = 保存上传(图片)
    img = 读图(原图路径)
    结果路径列表 = []
    信息 = {}
    if 方法 == '分类':
        全局 = globals()
        if '分类模型' not in 全局 or 全局.get('分类模型') is None:
            全局['分类模型'] = MobileNetV2(weights='imagenet')
        模型 = 全局['分类模型']
        pil = Image.open(原图路径).convert('RGB').resize((224,224))
        arr = np.array(pil, dtype=np.float32)
        x = np.expand_dims(arr, 0)
        x = preprocess_input(x)
        preds = 模型.predict(x)
        top5 = decode_predictions(preds, top=5)[0]
        信息['前五'] = [{'类别': c, '名称': n, '概率': float(p)} for (c,n,p) in top5]
        结果路径列表 = []
    elif 方法 == '平滑':
        高斯 = cv2.GaussianBlur(img, (5,5), 1.2)
        中值 = cv2.medianBlur(img, 5)
        双边 = cv2.bilateralFilter(img, 9, 75, 75)
        p1 = os.path.join(RESULT_DIR, uuid.uuid4().hex + '_高斯.png')
        p2 = os.path.join(RESULT_DIR, uuid.uuid4().hex + '_中值.png')
        p3 = os.path.join(RESULT_DIR, uuid.uuid4().hex + '_双边.png')
        存图(p1, 高斯); 存图(p2, 中值); 存图(p3, 双边)
        结果路径列表 = [p1,p2,p3]
    elif 方法 == '边缘':
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        canny = cv2.Canny(gray, 100, 200)
        sobelx = cv2.Sobel(gray, cv2.CV_16S, 1, 0)
        sobely = cv2.Sobel(gray, cv2.CV_16S, 0, 1)
        sobel = cv2.convertScaleAbs(cv2.addWeighted(cv2.convertScaleAbs(sobelx), 0.5, cv2.convertScaleAbs(sobely), 0.5, 0))
        p1 = os.path.join(RESULT_DIR, uuid.uuid4().hex + '_Canny.png')
        p2 = os.path.join(RESULT_DIR, uuid.uuid4().hex + '_Sobel.png')
        存图(p1, canny); 存图(p2, sobel)
        结果路径列表 = [p1,p2]
    elif 方法 == '轮廓':
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        blur = cv2.GaussianBlur(gray, (5,5), 1.0)
        _, th = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY+cv2.THRESH_OTSU)
        contours, _ = cv2.findContours(th, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        绘制 = img.copy()
        面积总 = 0
        for c in contours:
            area = cv2.contourArea(c); 面积总 += area
            x,y,w,h = cv2.boundingRect(c)
            cv2.drawContours(绘制, [c], -1, (0,255,0), 2)
            cv2.rectangle(绘制, (x,y), (x+w,y+h), (0,0,255), 2)
        p1 = os.path.join(RESULT_DIR, uuid.uuid4().hex + '_阈值.png')
        p2 = os.path.join(RESULT_DIR, uuid.uuid4().hex + '_轮廓.png')
        存图(p1, th); 存图(p2, 绘制)
        结果路径列表 = [p1,p2]
        信息['轮廓数量'] = len(contours)
        信息['面积总和'] = float(面积总)
    elif 方法 == '模板匹配':
        if not 模板:
            return HttpResponseRedirect(reverse('首页'))
        模板路径 = 保存上传(模板)
        tpl = 读图(模板路径)
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        tplg = cv2.cvtColor(tpl, cv2.COLOR_BGR2GRAY)
        res = cv2.matchTemplate(gray, tplg, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, max_loc = cv2.minMaxLoc(res)
        h, w = tplg.shape[:2]
        tl = max_loc
        br = (tl[0]+w, tl[1]+h)
        绘制 = img.copy()
        cv2.rectangle(绘制, tl, br, (0,0,255), 2)
        p = os.path.join(RESULT_DIR, uuid.uuid4().hex + '_匹配.png')
        存图(p, 绘制)
        结果路径列表 = [p]
        信息['最大相关'] = float(max_val)
    elif 方法 == '人脸':
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        xml = os.path.join(cv2.data.haarcascades, 'haarcascade_frontalface_default.xml')
        clf = cv2.CascadeClassifier(xml)
        faces = clf.detectMultiScale(gray, 1.2, 5)
        绘制 = img.copy()
        for (x,y,w,h) in faces:
            cv2.rectangle(绘制, (x,y), (x+w,y+h), (0,255,0), 2)
        p = os.path.join(RESULT_DIR, uuid.uuid4().hex + '_人脸.png')
        存图(p, 绘制)
        结果路径列表 = [p]
        信息['人脸数量'] = int(len(faces))
    else:
        return HttpResponseRedirect(reverse('首页'))
    项 = {
        'id': uuid.uuid4().hex,
        '时间': int(time.time()),
        '方法': 方法,
        '原图': os.path.relpath(原图路径, settings.MEDIA_ROOT).replace('\\','/'),
        '结果': [os.path.relpath(x, settings.MEDIA_ROOT).replace('\\','/') for x in 结果路径列表],
        '信息': 信息
    }
    记录历史(项)
    return render(request, 'result.html', {'项': 项})

def 历史(request):
    初始化()
    with open(HISTORY_PATH, 'r', encoding='utf-8') as f:
        数据 = json.load(f)
    return render(request, 'history.html', {'数据': 数据})
