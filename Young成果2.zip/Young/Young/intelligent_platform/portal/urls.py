from django.urls import path
from . import views
urlpatterns = [
    path('', views.首页, name='首页'),
    path('process/', views.处理, name='处理'),
    path('history/', views.历史, name='历史'),
]
